
const path = require('path');
const express = require('express');
const ejs = require('ejs');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const app = express();

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'password',
    database: 'users_data'
});

connection.connect(function (error) {
    if (!!error) console.log(error);
    else console.log('Database Connected!');
});

//set views file
app.set('views', path.join(__dirname, 'views'));

//set view engine
app.set('view engine', 'ejs');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.get('/add_user', (req, res, next) => {
    res.render('add_user');
});

app.get('/add_service', (req, res, next) => {
    res.render('add_service');
})

// DASHBOARD PAGE
app.get('/', (req, res) => {
    let sql = "SELECT * FROM users";
    let query = connection.query(sql, (err, rows) => {
        if (err) throw err;
        res.render('user_index', {
            title: 'CRUD Operation using NodeJS / ExpressJS / MySQL',
            users: rows
        });
    });
});


// INSERT USER DATA

app.post('/add_user', function (req, res) {
    var users_id = req.body.users_id;
    var customer_name = req.body.customer_name;
    var email = req.body.email;
    var mobileno = req.body.mobileno;
    var dob = req.body.dob;
    var address = req.body.address;
    var country = req.body.country;

    var sql = `INSERT INTO users(users_id,customer_name,email,mobileno,dob,address,country)values('${users_id}','${customer_name}','${email}','${mobileno}','${dob}','${address}','${country}') `;
    connection.query(sql, function (err, results) {
        if (err) throw err;
        res.redirect('/show');
    });
});

// INSERT SERVICE DATA 
app.post('/add_service', function (req, res) {

    var service_id = req.body.service_id;
    var customer_name = req.body.customer_name;
    var vehicle_no = req.body.vehicle_no;
    var pickup_date = req.body.pickup_date;
    var drop_date = req.body.drop_date;
    var vehicle_name = req.body.vehicle_name;
    var location = req.body.location;
    var service_location = req.body.service_location;
    var service_price = req.body.service_price;
    var payable_amount = req.body.payable_amount;

    var sql = `INSERT INTO services(service_id,customer_name,vehicle_no,location,service_location,service_price,payable_amount,pickup_date,drop_date)values('${service_id}','${customer_name}','${vehicle_no}','${location}','${service_location}','${service_price}','${payable_amount}','${pickup_date}','${drop_date}') `;
    connection.query(sql, function (err, results) {
        if (err) throw err;
        res.redirect('/service_view');
    });
});


// SHOW USER DATA
app.get('/show', (req, res) => {

    var sql = "select *from users";
    connection.query(sql, function (err, results) {
        if (err) throw err;
        res.render('show', { users: results });
    })

})

// SHOW SERVICE DATA
app.get('/service_view', (req, res) => {
    var sql = "select *from services";
    connection.query(sql, function (err, results) {
        if (err) throw err;
        res.render('service_view', { services: results });
    })

})


// DELETE USER DATA
app.get('/delete/:id', function (req, res) {
    var id = req.params.id;
    var sql = `delete from users where users_id='${id}'`;

    connection.query(sql, function (err, results) {
        if (err) throw err;
        res.redirect('/show');
    })
})
// DELETE SERVICE DATA
app.get('/delete_service/:id', function (req, res) {
    var id = req.params.id;
    var sql = `delete from services where service_id='${id}'`;

    connection.query(sql, function (err, results) {
        if (err) throw err;
        res.redirect('/service_view');
    })
})


// Edit USER DATA
app.get('/edit/:id', function (req, res) {
    var id = req.params.id;
    var sql = `select *from users where users_id='${id}'`;
    connection.query(sql, function (err, results) {
        if (err) throw err;
        res.render('edit', { users: results });
    })
})

// EDIT SERVICE DATA
app.get('/edit_service/:id', function (req, res) {
    var id = req.params.id;
    var sql = `select *from services where service_id='${id}'`;
    connection.query(sql, function (err, results) {
        if (err) throw err;
        res.render('service_edit', { services: results });
    })
})



// UPDATE USER DATA

app.post('/update/:id', function (req, res) {
    var id = req.params.id;
    var users_id = req.body.users_id;
    var customer_name = req.body.customer_name;
    var email = req.body.email;
    var mobileno = req.body.mobileno;
    var dob = req.body.dob;
    var address = req.body.address;
    var country = req.body.country;

    var sql = `update users set users_id='${users_id}',customer_name='${customer_name}',email='${email}',mobileno='${mobileno}', dob ='${dob}',address='${address}', country='${country}' where users_id = '${id}' `;

    connection.query(sql, function (err, results) {
        if (err) throw err;
        res.redirect('/show');
    })
})

//UPDATE SERVICE DATA
app.post('/update_service/:id', function (req, res) {
    var id = req.params.id;
    var service_id = req.body.service_id;
    var customer_name = req.body.customer_name;
    var vehicle_no = req.body.vehicle_no;
    var pickup_date = req.body.pickup_date;
    var drop_date = req.body.drop_date;
    var location = req.body.location;
    var service_location = req.body.service_location;
    var service_price = req.body.service_price;
    var payable_amount = req.body.payable_amount;


    var sql = `update services set service_id='${service_id}',customer_name='${customer_name}',vehicle_no='${vehicle_no}',pickup_date='${pickup_date}', drop_date ='${drop_date}',location='${location}', service_location='${service_location}',service_price='${service_price}',payable_amount='${payable_amount}' where service_id = '${id}'`;

    connection.query(sql, function (err, results) {
        if (err) throw err;
        res.redirect('/service_view');
    })
})

// GET CUSTOMER DETAILS BY ID  
app.get('/customer_data/:id', (req, res) => {
    console.log('Fetching user with id: ', req.params.id)
    const sql = 'SELECT * FROM users WHERE users_id = ?'
    connection.query(sql, [req.params.id], (err, rows, results) => {
        if (err) {
            console.log('Failed to query for users ', err);
            res.status(500)
            res.end();
            return;
        }
        console.log('I think we fetch user id succesfully');
        res.json(rows);

    })

})

// GET SERVICE DETAILS BY ID  
app.get('/service_data/:id', (req, res) => {
    console.log('Fetching services with id: ', req.params.id)
    const sql = 'SELECT * FROM services WHERE service_id = ?'
    connection.query(sql, [req.params.id], (err, rows, results) => {
        if (err) {
            console.log('Failed to query for services ', err);
            res.status(500)
            res.end();
            return;
        }
        console.log('I think we fetch service id succesfully');
        res.json(rows);

    })

})

// Server Listening
app.listen(2020, () => {
    console.log('Server is running at port 2020');
});



